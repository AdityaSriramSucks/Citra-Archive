#!/bin/bash -ex

# Run clang-format
./.ci/linux-clang-format/script.sh
