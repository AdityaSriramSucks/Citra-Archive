From https://github.com/yhirose/cpp-httplib/commit/8e10d4e8e7febafce0632810262e81e853b2065f

MIT License

===

cpp-httplib

A C++11 header-only HTTP library.

It's extremely easy to setup. Just include httplib.h file in your code!

Inspired by Sinatra and express.

© 2017 Yuji Hirose

